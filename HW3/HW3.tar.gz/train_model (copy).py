import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim.lr_scheduler as LRscheduler
from torch.autograd import Variable
import os

import utils
import models

# Hyper Parameters
embed_size = 249
num_epochs = 0
num_samples = 1000  # number of words to be sampled
temperature = 1.0
batch_size = [20]
seq_lengths = [30]
learning_rate = [0.002]

#TODO: CHANGE THE MODEL NUMBER TO THE ONE YOU NEED
model_num = 4

# Load Penn Treebank Dataset
train_path = './data/train.txt'
valid_path = './data/valid.txt'
sample_path = './sample.txt'
save_dir = './saved models/'

def evaluate(model,corpus,criterion,path,num_layers,
             hidden_size,batch_size,seq_length):
    # Turn on evaluation mode which disables dropout.
    Ids = corpus.get_data(path, batch_size)
    model.eval()
    totalLoss = 0
    ntokens = len(corpus.dictionary)
    states = (Variable(torch.zeros(num_layers, batch_size, hidden_size)).cuda(),
              Variable(torch.zeros(num_layers, batch_size, hidden_size)).cuda())
    lossNum = 0
    for i in range(0, Ids.size(1) - seq_length, seq_length):
        model.zero_grad()
        inputs = Variable(Ids[:, i:i + seq_length]).cuda()
        targets = Variable(Ids[:, (i + 1):(i + 1) + seq_length].contiguous()).cuda()
        states = detach(states)
        outputs, states = model(inputs, states)
        #print(totalLoss)
        totalLoss += criterion(outputs, targets.view(-1)).data
        lossNum += 1
    return np.average(totalLoss/lossNum)

def detach(states):
    return [state.detach() for state in states]

for bs in batch_size:
    # Create corpuses
    train_corpus = utils.Corpus()
    ids_train = train_corpus.get_data(train_path, bs)
    ids_valid = train_corpus.get_data(valid_path, bs)
    train_vocab_size = len(train_corpus.dictionary)

    for seq_len in seq_lengths:
        num_train_batches = ids_train.size(1) // seq_len
        num_valid_batches = ids_valid.size(1) // seq_len

        for lr in learning_rate:
            model = utils.initialize_model(model_num, train_vocab_size, embed_size)
            model = utils.use_cuda(model)
            print('Training vocabulary size: {}'.format(train_vocab_size))
            print('Model: {}'.format(model.name))
            print('Number of parameters = {}'.format(sum(p.numel() for p in model.parameters())))

            run_name = "{}, seq_len={}, lr={}, bs={}".format(model.name, seq_len, lr, bs)
            file_path = os.path.join(save_dir,run_name + '.pkl')

            # Loss and Optimizer
            criterion = nn.CrossEntropyLoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=lr)
            #TODO: CHANGE PARAMETERS - EPS, PATIENCE, etc.. CHECK OTHER TYPES OF SCHEDULER!!  https://pytorch.org/docs/stable/optim.html
            lr_scheduler = LRscheduler.ReduceLROnPlateau(optimizer,eps= 1e-9)

            # Load model parameters and optimizer condition if available
            if os.path.exists(file_path):
                model, optimizer, lr_scheduler = utils.load_checkpoint(model, optimizer, lr_scheduler, file_path)

            model.cuda()
            #model, optimizer, lr_scheduler = utils.load_checkpoint(model, optimizer, lr_scheduler, file_path)
            #model.load_state_dict(torch.load('model.pkl', map_location=lambda storage, loc: storage))
            model.eval()
            criterion = nn.CrossEntropyLoss()

            with open('story.txt', 'w') as f:
                f.write('---Evaluating The Model---\n')
                f.write('1) number of parameters: ' + str(sum(param.numel() for param in model.parameters())) + '\n')
                testLoss = evaluate(model, train_corpus, criterion, './data/test.txt', 1, 249,
                                    batch_size, 10000)
                f.write('2) Preplexity of test set: %5.2f\n' % (np.exp(testLoss)))
            with open('story.txt', 'a') as f:
                f.write('Here you can see the story generated with the starting words:\n')
                f.write('buy low sell high is the\n')
                f.write('for 3 different temperatures\n')
                f.write('*in words 2-6 there is a / seprating the input word and the predicted word\n')
                f.write('(the left word was the input)\n')


            def writeBuyLowStory(temperature, testInput):
                prob = torch.ones(10000)
                state = (Variable(torch.zeros(1, 1, 249)).cuda(),
                         Variable(torch.zeros(1, 1, 249)).cuda())
                with open('story.txt', 'a') as f:
                    f.write('\n---writing story temperature: ' + str(temperature) + '---' + '\n')
                    word = train_corpus.dictionary.idx2word[int(testInput[0])]
                    word = '\n' if word == '<eos>' else word + ' '
                    f.write(word)
                    for i in range(5):
                        output, state = model(testInput[i], state)
                        # print(int(testInput[i+1]))
                        prob = output.squeeze().data.div(temperature).exp().cpu()
                        word_id = torch.multinomial(prob, 1)[0]
                        word = train_corpus.dictionary.idx2word[int(testInput[i + 1])] + '/' + corpus.dictionary.idx2word[
                            word_id]
                        word = '\n' if word == '<eos>' else word + ' '
                        f.write(word)
                    input = testInput[5]
                    for i in range(6, 30):
                        # Forward propagate rnn
                        output, state = model(input, state)

                        # Sample a word id
                        prob = output.squeeze().data.exp().cpu()
                        word_id = torch.multinomial(prob, 1)[0]

                        # Feed sampled word id to next time step
                        input.data.fill_(word_id)

                        # File write
                        word = train_corpus.dictionary.idx2word[word_id]
                        word = '\n' if word == '<eos>' else word + ' '
                        f.write(word)
                    f.write('\n')


            testInput = ['buy', 'low', 'sell', 'high', 'is', 'the']
            i = 0
            for inp in testInput:
                testInput[i] = Variable(torch.cuda.LongTensor([[train_corpus.dictionary.word2idx[inp]]]),
                                        volatile=True).cuda()
                i += 1
            writeBuyLowStory(1, testInput)
            testInput = ['buy', 'low', 'sell', 'high', 'is', 'the']
            i = 0
            for inp in testInput:
                testInput[i] = Variable(torch.cuda.LongTensor([[train_corpus.dictionary.word2idx[inp]]]),
                                        volatile=True).cuda()
                i += 1
            writeBuyLowStory(0.1, testInput)
            testInput = ['buy', 'low', 'sell', 'high', 'is', 'the']
            i = 0
            for inp in testInput:
                testInput[i] = Variable(torch.cuda.LongTensor([[train_corpus.dictionary.word2idx[inp]]]),
                                        volatile=True).cuda()
                i += 1
            writeBuyLowStory(0.01, testInput)



# Sampling
with open(sample_path, 'w') as f:
    # Set intial hidden ane memory states
    state = (utils.use_cuda(torch.zeros(model.num_layers, 1, model.hidden_size)),
             utils.use_cuda(torch.zeros(model.num_layers, 1, model.hidden_size)))

    # Select one word id randomly
    prob = torch.ones(train_vocab_size)
    input = utils.use_cuda(torch.multinomial(prob, num_samples=1).unsqueeze(1))

    for i in range(num_samples):
        # Forward propagate rnn
        output, state = model(input, state)

        # Sample a word id
        word_weights = output.squeeze().div(temperature).exp().cpu()
        word_id = torch.multinomial(word_weights, 1).item()

        # Feed sampled word id to next time step
        input.data.fill_(word_id)

        # File write
        word = train_corpus.dictionary.idx2word[word_id]
        word = '\n' if word == '<eos>' else word + ' '
        f.write(word)

        if (i + 1) % 20 == 0:
            print('Sampled [%d/%d] words and save to %s' % (i + 1, num_samples, sample_path))

