#-------------imorts----------#OA
import torch
import torch.nn as nn
import numpy as np
from torch.autograd import Variable
from utils
import models as mod


trainPath = './data/train.txt'
validPath = './data/valid.txt'
testPath = './data/test.txt'

#-------------methods----------#
def evaluate(model,corpus,criterion,path,num_layers,
             hidden_size,batch_size,seq_length):
    # Turn on evaluation mode which disables dropout.
    Ids = corpus.get_data(path, batch_size)
    model.eval()
    totalLoss = 0
    ntokens = len(corpus.dictionary)
    states = (Variable(torch.zeros(num_layers, batch_size, hidden_size)).cuda(),
              Variable(torch.zeros(num_layers, batch_size, hidden_size)).cuda())
    lossNum = 0
    for i in range(0, Ids.size(1) - seq_length, seq_length):
        model.zero_grad()
        inputs = Variable(Ids[:, i:i + seq_length]).cuda()
        targets = Variable(Ids[:, (i + 1):(i + 1) + seq_length].contiguous()).cuda()
        states = detach(states)
        outputs, states = model(inputs, states)
        #print(totalLoss)
        totalLoss += criterion(outputs, targets.view(-1)).data
        lossNum += 1
    return np.average(totalLoss/lossNum)

def detach(states):
    return [state.detach() for state in states]

def toVar(x):
    if torch.cuda.is_available():
        x = x.cuda()
    return Variable(x)

# Hyper Parameters
embed_size = 249
batch_size = 20
seq_length = 30
#sample_path = './sample.txt'
corpus = Corpus()
ids = corpus.get_data(trainPath, batch_size)
vocab_size = len(corpus.dictionary)
num_batches = ids.size(1) // seq_length

def evaluate_hw3():
    model = mod.model4(vocab_size, embed_size)
    model.cuda()
    model, optimizer, lr_scheduler = utils.load_checkpoint(model, optimizer, lr_scheduler, file_path)
    model.load_state_dict(torch.load('model.pkl', map_location=lambda storage, loc: storage))
    model.eval()
    criterion = nn.CrossEntropyLoss()

    with open('story.txt', 'w') as f:
        f.write('---Evaluating The Model---\n')
        f.write('1) number of parameters: ' + str(sum(param.numel() for param in model.parameters())) + '\n')
        testLoss = evaluate(model,corpus,criterion,'./PennTreeBankData/test.txt',num_layers,hidden_size,batch_size,seq_length)
        f.write('2) Preplexity of test set: %5.2f\n'%(np.exp(testLoss)))
    with open('story.txt', 'a') as f:
        f.write('Here you can see the story generated with the starting words:\n')
        f.write('buy low sell high is the\n')
        f.write('for 3 different temperatures\n')
        f.write('*in words 2-6 there is a / seprating the input word and the predicted word\n')
        f.write('(the left word was the input)\n')

    def writeBuyLowStory(temperature, testInput):
        prob = torch.ones(vocab_size)
        state = (Variable(torch.zeros(num_layers, 1, hidden_size)).cuda(),
                 Variable(torch.zeros(num_layers, 1, hidden_size)).cuda())
        with open('story.txt', 'a') as f:
            f.write('\n---writing story temperature: ' + str(temperature) + '---' + '\n')
            word = corpus.dictionary.idx2word[int(testInput[0])]
            word = '\n' if word == '<eos>' else word + ' '
            f.write(word)
            for i in range(5):
                output, state = model(testInput[i], state)
                #print(int(testInput[i+1]))
                prob = output.squeeze().data.div(temperature).exp().cpu()
                word_id = torch.multinomial(prob, 1)[0]
                word = corpus.dictionary.idx2word[int(testInput[i + 1])] + '/' + corpus.dictionary.idx2word[word_id]
                word = '\n' if word == '<eos>' else word + ' '
                f.write(word)
            input = testInput[5]
            for i in range(6, 30):
                # Forward propagate rnn
                output, state = model(input, state)

                # Sample a word id
                prob = output.squeeze().data.exp().cpu()
                word_id = torch.multinomial(prob, 1)[0]

                # Feed sampled word id to next time step
                input.data.fill_(word_id)

                # File write
                word = corpus.dictionary.idx2word[word_id]
                word = '\n' if word == '<eos>' else word + ' '
                f.write(word)
            f.write('\n')

    testInput = ['buy', 'low', 'sell', 'high', 'is', 'the']
    i = 0
    for inp in testInput:
        testInput[i] = Variable(torch.cuda.LongTensor([[corpus.dictionary.word2idx[inp]]]), volatile=True).cuda()
        i += 1
    writeBuyLowStory(1,testInput)
    testInput = ['buy', 'low', 'sell', 'high', 'is', 'the']
    i = 0
    for inp in testInput:
        testInput[i] = Variable(torch.cuda.LongTensor([[corpus.dictionary.word2idx[inp]]]), volatile=True).cuda()
        i += 1
    writeBuyLowStory(0.1,testInput)
    testInput = ['buy', 'low', 'sell', 'high', 'is', 'the']
    i = 0
    for inp in testInput:
        testInput[i] = Variable(torch.cuda.LongTensor([[corpus.dictionary.word2idx[inp]]]), volatile=True).cuda()
        i += 1
    writeBuyLowStory(0.01,testInput)


evaluate_hw3()
